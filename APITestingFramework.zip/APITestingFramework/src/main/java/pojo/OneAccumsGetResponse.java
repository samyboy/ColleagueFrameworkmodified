package pojo;
//import org.testng.Assert;

import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OneAccumsGetResponse {

	@JsonProperty("TranslationItemList")
	private ArrayList<JsonResponseData> translationItemList = new ArrayList<JsonResponseData>();

	public ArrayList<JsonResponseData> getTranslationItemList() {
		return translationItemList;
	}

	public void setTranslationItemList(ArrayList<JsonResponseData> translationItemList) {
		this.translationItemList = translationItemList;
	}
	
	
}

