package pojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.opencsv.bean.CsvBindByName;

public class OneAccumsGetRequest {
	
	

	@CsvBindByName(column = "OrganizationCode")
	@JsonProperty("OrganizationCode")
	private String OrganizationCode;
	
	@CsvBindByName(column = "MemberHCID")
	@JsonProperty("MemberHCID")
	private String MemberHCID;
	
	@CsvBindByName(column = "MemberCode")
	@JsonProperty("MemberCode")
	private String MemberCode;
	
	@CsvBindByName(column = "MemberCase")
	@JsonProperty("MemberCase")
	private String MemberCase;
	
	@CsvBindByName(column = "MemberContract")
	@JsonProperty("MemberContract")
	private String MemberContract;
	
	@CsvBindByName(column = "AccumStartDate")
	@JsonProperty("AccumStartDate")
	private String AccumStartDate;
	
	@CsvBindByName(column = "AccumEndDate")
	@JsonProperty("AccumEndDate")
	private String AccumEndDate;
	
	@CsvBindByName(column = "ClaimNetwork")
	@JsonProperty("ClaimNetwork")
	private String ClaimNetwork;
	
	@CsvBindByName(column = "AccumName")
	@JsonProperty("AccumName")
	private String AccumName;
	
	@CsvBindByName(column = "DiagnosisCode")
	@JsonProperty("DiagnosisCode")
	private String DiagnosisCode;
	
	@CsvBindByName(column = "MemberTier")
	@JsonProperty("MemberTier")
	private String MemberTier;
	
	@CsvBindByName(column = "ProviderTaxId")
	@JsonProperty("ProviderTaxId")
	private String ProviderTaxId;

	public String getOrganizationCode() {
		return OrganizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.OrganizationCode = organizationCode;
	}

	public String getMemberHCID() {
		return MemberHCID;
	}

	public void setMemberHCID(String memberHCID) {
		this.MemberHCID = memberHCID;
	}

	public String getMemberCode() {
		return MemberCode;
	}

	public void setMemberCode(String memberCode) {
		this.MemberCode = memberCode;
	}

	public String getMemberCase() {
		return MemberCase;
	}

	public void setMemberCase(String memberCase) {
		this.MemberCase = memberCase;
	}

	public String getMemberContract() {
		return MemberContract;
	}

	public void setMemberContract(String memberContract) {
		this.MemberContract = memberContract;
	}

	public String getAccumStartDate() {
		return AccumStartDate;
	}

	public void setAccumStartDate(String accumStartDate) {
		this.AccumStartDate = accumStartDate;
	}

	public String getAccumEndDate() {
		return AccumEndDate;
	}

	public void setAccumEndDate(String accumEndDate) {
		this.AccumEndDate = accumEndDate;
	}

	public String getClaimNetwork() {
		return ClaimNetwork;
	}

	public void setClaimNetwork(String claimNetwork) {
		this.ClaimNetwork = claimNetwork;
	}

	public String getAccumName() {
		return AccumName;
	}

	public void setAccumName(String accumName) {
		this.AccumName = accumName;
	}

	public String getDiagnosisCode() {
		return "";
	}

	public void setDiagnosisCode(String diagnosisCode) {
		DiagnosisCode = diagnosisCode;
	}

	public String getMemberTier() {
		return MemberTier;
	}

	public void setMemberTier(String memberTier) {
		this.MemberTier = memberTier;
	}

	public String getProviderTaxId() {
		return ProviderTaxId;
	}

	public void setProviderTaxId(String providerTaxId) {
		this.ProviderTaxId = providerTaxId;
	}
	
	
}
