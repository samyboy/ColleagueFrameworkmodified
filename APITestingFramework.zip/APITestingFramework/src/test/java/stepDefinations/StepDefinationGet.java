package stepDefinations;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import pojo.OneAccumsGetRequest;
//import resources.TestDataBuild;
import resources.Utils;

public class StepDefinationGet extends Utils {
	List<RequestSpecification> requests = new ArrayList<RequestSpecification>();
	ResponseSpecification resspec;
	List<Response> responses = new ArrayList<Response>();
	// TestDataBuild data = new TestDataBuild();

	@Given("{string} Accum Transaction Payload from CSV getFlow")
	public void accum_transaction_payload_from_csv_get_flow(String requestType) throws IOException {
		// Write code here that turns the phrase above into concrete actions
 
        String csvFilePath = System.getProperty("user.dir")+"\\GetPayload.csv";
		try {
			List<OneAccumsGetRequest> summaryData = Utils.csvToObject(csvFilePath,OneAccumsGetRequest.class);
			resspec = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
			for (OneAccumsGetRequest transaction : summaryData) {
				//requests.add(given().spec(requestSpecification(requestType)).body(createGetRequest(transaction)));
				requests.add(given().spec(requestSpecification(requestType)).body(transaction));
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception :"+e);
		}
	}

	@When("user calls {string} with {string} http request getFlow")
	public void user_calls_with_http_request_get_flow(String resource, String method) throws IOException {
		// Write code here that turns the phrse above into concrete actions
		
		//resspec = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
		try {
			for (RequestSpecification request : requests) {
				if (method.equalsIgnoreCase("Get")) {
					responses.add(request.when().post(getGlobalValue(resource)));
				}	
				else if (method.equalsIgnoreCase("Post")) {
					responses.add(request.when().post(getGlobalValue(resource)));
				}				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception :"+e);
		}
	}

	@Then("the API call got success with status code {int} getFlow")
	public void the_api_call_got_success_with_status_code_get_flow(Integer int1) {
		// Write code here that turns the phrase above into concrete actions
		// System.out.println("Response Code" +responses.getStatusCode());
		
		try {
			for (Response response : responses) {
				System.out.println(response.getStatusCode());
				//assertEquals(200, response.getStatusCode());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Exception :"+e.getMessage());
		}
	}

	@Then("{string} in response  body is {string} getFlow")
	public void in_response_body_is_get_flow(String string, String string2) {
		// Write code here that turns the phrase above into concrete actions
		try {
			for (Response response : responses) {
				//assertEquals(getJsonPath(response, keyValue), expectedValue);
				//System.out.println(getJsonPath(response, keyValue));
				//getJsonPath(response, keyValue);
				fn_ResponseFromOneAccums(response.asString());
				System.out.println("Parse Response");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("Exception :"+e);
		}
	}
}
